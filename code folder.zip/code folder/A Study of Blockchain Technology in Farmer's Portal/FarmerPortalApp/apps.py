from django.apps import AppConfig


class FarmerportalappConfig(AppConfig):
    name = 'FarmerPortalApp'
